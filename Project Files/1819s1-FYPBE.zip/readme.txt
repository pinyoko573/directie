Do remember to read on the deployment guide before deploying!
Remember to also 'npm install' to install all the plugins needed!!