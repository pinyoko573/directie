var mysql = require('mysql');
var config = require('./config.json');
var pool = mysql.createPool({
    host: config.dbhost,
    user: config.dbuser,
    password: config.dbpassword,
    database: config.dbname,
    multipleStatements: true
});
exports.handler = (event, context, callback) => {
    if (event.type == "Beacon") {
        if (event.action == "getBeacon") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from beacon', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putBeacon") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UUID = event.UUID;
                var Major = event.Major;
                var Minor = event.Minor;
                var TurningPoint = event.TurningPoint;
                var BeaconID = event.BeaconID;
                var values = [UUID, Major, Minor, TurningPoint, BeaconID];
                connection.query('update beacon set UUID=?,Major=?,Minor=?,TurningPoint=? where BeaconID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putToggle") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var Toggle = event.Toggle;
                var BeaconID = event.BeaconID;
                var values = [Toggle, BeaconID];
                connection.query('update beacon set Toggle=? where BeaconID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "deleteBeacon") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                connection.query('delete from beacon where BeaconID=?', BeaconID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createBeacon") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                var UUID = event.UUID;
                var Major = event.Major;
                var Minor = event.Minor;
                var TurningPoint = event.TurningPoint;
                var Toggle = event.Toggle;
                var records = [BeaconID, UUID, Major, Minor, TurningPoint, Toggle];
                connection.query('insert into beacon values(?, ?, ?, ?, ?, ?)', records, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "getBeaconById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                connection.query('SELECT * from beacon where BeaconID = ?', BeaconID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "getBRoute") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT CurrentBID as beaconID, PreviousBID as PB,NextBID as NB,Action as DIR, TurningPoint, Compass, Note FROM bdirection as bd Join direction as d on bd.DirectID = d.DirectID Join beacon as b on b.beaconID = bd.CurrentBID order by CurrentBID asc; SELECT BeaconID, RelatedBeacon FROM brelation;SELECT BeaconID, FacilityName,FacilityInfo,ImageURL from beaconunit as bu join unit as u on bu.UnitID = u.UnitID join facilityunit as fu on u.UnitID = fu.UnitID join facility as f on f.FacilityID = fu.FacilityID join facilityimage as fi on f.FacilityID = fi.FacilityID join image as i on fi.ImageID = i.ImageID;SELECT BeaconID, UnitNo, UnitName from beaconunit as bu join unit as u on bu.UnitID = u.UnitID;', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (err) {
                        callback(err);
                        return;
                    }
                    else {
                        var bd = results[0];
                        var br = results[1];
                        var bf = results[2];
                        var bu = results[3];
                        var bjson = {
                            Beacons: []
                        };
                        var hold;
                        var beaconInfo = [];
                        var relatedBeacons = [];
                        var unit = [];
                        var unitName = [];
                        var facilityName = [];
                        var facilityDesc = [];
                        var facilityImg = [];
                        var turningPoint;

                        //var PB;
                        //var NB;
                        for (var i = 0; i < bd.length; i++) {
                            if (hold != bd[i].beaconID) {
                                for (var j = 0; j < bd.length; j++) {
                                    if (bd[j].beaconID == bd[i].beaconID) {
                                        beaconInfo.push({
                                            PB: bd[j].PB,
                                            NB: bd[j].NB,
                                            DIR: bd[j].DIR,
                                            Compass: bd[j].Compass,
                                            Note: bd[j].Note
                                        });
                                        var check;
                                        if (bd[j].TurningPoint == 1) {
                                            check = true
                                        } else {
                                            check = false
                                        }
                                        turningPoint = check;
                                    }
                                }
                                for (var k = 0; k < br.length; k++) {
                                    if (bd[i].beaconID == br[k].BeaconID) {
                                        relatedBeacons.push(br[k].RelatedBeacon);
                                    }
                                }
                                for (var l = 0; l < bf.length; l++) {
                                    if (bd[i].beaconID == bf[l].BeaconID) {
                                        facilityName.push(bf[l].FacilityName);
                                        facilityDesc.push(bf[l].FacilityInfo);
                                        facilityImg.push(bf[l].ImageURL);
                                    }
                                }
                                for (var m = 0; m < bu.length; m++) {
                                    if (bd[i].beaconID == bu[m].BeaconID) {
                                        unit.push(bu[m].UnitNo);
                                        unitName.push(bu[m].UnitName);
                                    }
                                }
                                bjson.Beacons.push({
                                    beaconID: bd[i].beaconID,
                                    beaconInfo,
                                    relatedBeacons,
                                    turningPoint,
                                    unit,
                                    unitName,
                                    facilityName,
                                    facilityDesc,
                                    facilityImg
                                });
                                beaconInfo = [];
                                relatedBeacons = [];
                                unit = [];
                                unitName = [];
                                facilityName = [];
                                facilityDesc = [];
                                facilityImg = [];
                                hold = bd[i].beaconID;
                            }
                        }
                        callback(null, bjson);
                    }
                });
            });
        }
    } else if (event.type == "Facility") {
        if (event.action == "getFacility") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT f.FacilityID,FacilityName,FacilityInfo,i.ImageID,ImageURL FROM facility as f join facilityimage as fi on f.FacilityID = fi.FacilityID join image as i on fi.ImageID = i.ImageID ORDER BY FacilityID DESC;', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putFacility") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityName = event.FacilityName;
                var FacilityInfo = event.FacilityInfo;
                var FacilityID = event.FacilityID;
                var ImageURL = event.ImageURL;
                var Category = event.Category;
                var ImageID = event.ImageID;
                var UnitID = event.UnitID;
                var existingRecords = "";
                var values = [FacilityName, FacilityInfo, FacilityID, ImageURL, Category, ImageID];
                connection.query('update facility set FacilityName=?,FacilityInfo=? where FacilityID=?;Update image as i inner join facilityimage as fi on i.ImageID = fi.ImageID set ImageURL = ?, Category = ? where fi.ImageID = ?;', values, function (error, results, fields) {
                    // And done with the connection.
                    //connection.release();
                    // Handle error after the release.
                    if (err) {
                        callback(err);
                        return;
                    }
                    //else callback(null, results);
                });

                for (var i in UnitID) {
                    var records = [FacilityID, UnitID[i], FacilityID, UnitID[i]];
                    console.log(UnitID[i]);
                    if (i == UnitID.length - 1) {
                        connection.query('INSERT INTO facilityunit (FacilityID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT FUID FROM facilityunit WHERE FacilityID=? AND UnitID=?);', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    } else {
                        connection.query('INSERT INTO facilityunit (FacilityID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT FUID FROM facilityunit WHERE FacilityID=? AND UnitID=?);', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    }
                }

                for (var i = 0; i < UnitID.length; i++) {
                    if (i == 0) {
                        existingRecords += "SELECT " + FacilityID + ", " + UnitID[i];
                    } else {
                        existingRecords += " UNION ALL SELECT " + FacilityID + ", " + UnitID[i];
                    }
                }
                if (UnitID.length == 0) {
                    connection.query('DELETE FROM facilityunit WHERE FacilityID=?;', FacilityID, function (error, results, fields) {
                        console.log(existingRecords);
                        connection.release();
                        // Handle error after the release.
                        if (error) callback(error);
                        else callback(null, results)
                    });
                } else {
                    connection.query('DELETE FROM facilityunit WHERE FacilityID=? AND (FacilityID, UnitID) NOT IN (' + existingRecords + ');', FacilityID, function (error, results, fields) {
                        console.log(existingRecords);
                        connection.release();
                        // Handle error after the release.
                        if (error) callback(error);
                        else callback(null, results)
                    });
                }


            });
        } else if (event.action == "deleteFacility") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityID = event.FacilityID;
                var values = [FacilityID, FacilityID, FacilityID];
                connection.query('delete from facilityimage where FacilityID=?;delete from facilityunit where FacilityID=?;delete from facility where FacilityID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createFacility") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityName = event.FacilityName;
                var FacilityInfo = event.FacilityInfo;
                var ImageURL = event.ImageURL;
                var Category = event.Category;
                var UnitID = event.UnitID;
                var records = [FacilityName, FacilityInfo, ImageURL, Category];
                connection.query('insert into facility values(0 , ?, ?);insert into image values(0 , ?, ?)', records, function (error, results, fields) {
                    if (error) {
                        callback(error);
                        return;
                    }
                    var FacilityID = results[0].insertId;
                    var ImageID = results[1].insertId;
                    records = [FacilityID, ImageID];
                    //result.push(results);

                    connection.query('insert into facilityimage values(0 , ?, ?)', records, function (error, results, fields) {
                        if (error) { callback(error); }
                        if (UnitID.length == 0) {
                            connection.release();
                            callback(null, results);
                        }
                    });

                    for (var i in UnitID) {
                        var records = [FacilityID, UnitID[i], FacilityID, UnitID[i]];
                        console.log(UnitID[i]);
                        if (i == UnitID.length - 1) {
                            connection.query('INSERT INTO facilityunit (FacilityID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT FUID FROM facilityunit WHERE FacilityID=? AND UnitID=?)', records, function (error, results, fields) {
                                connection.release();
                                // Handle error after the release.
                                if (error) callback(error);
                                else callback(null, results)
                            });
                        } else {
                            connection.query('INSERT INTO facilityunit (FacilityID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT FUID FROM facilityunit WHERE FacilityID=? AND UnitID=?)', records, function (error, results, fields) {

                                if (error) {
                                    callback(error);
                                    return;
                                }
                            });
                        }
                    }
                });

            });
        } else if (event.action == "getFacilityById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityID = event.FacilityID;
                connection.query('SELECT f.FacilityID,FacilityName,FacilityInfo,ImageURL,i.ImageID FROM facility as f join facilityimage as fi on f.FacilityID = fi.FacilityID join image as i on fi.ImageID = i.ImageID where f.FacilityID = ?;', FacilityID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "Unit") {
        if (event.action == "getUnit") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }

                // Use the connection
                connection.query('SELECT u.UnitID,UnitNo,Level,Block,UnitName,i.ImageID,ImageURL FROM unit as u join unitimage as ui on u.UnitID = ui.UnitID join image as i on ui.ImageID = i.ImageID ORDER BY UnitID DESC;', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UnitNo = event.UnitNo;
                var Level = event.Level;
                var Block = event.Block;
                var UnitID = event.UnitID;
                var UnitName = event.UnitName;
                var ImageURL = event.ImageURL;
                var Category = event.Category;
                var ImageID = event.ImageID;
                var BeaconID = event.BeaconID;
                var existingRecords = "";
                var values = [UnitNo, Level, Block, UnitName, UnitID, ImageURL, Category, ImageID];

                if (isNaN(ImageURL)) {
                    connection.query('update unit set UnitNo=?,Level=?,Block=?,UnitName=? where UnitID=?;Update image as i inner join unitimage as ui on i.ImageID = ui.ImageID set ImageURL = ?, Category = ? where ui.ImageID = ?;', values, function (error, results, fields) {
                        // And done with the connection.
                        //connection.release();
                        // Handle error after the release.
                        if (error) {
                            callback(error);
                            return;
                        }
                        //else callback(null, results);
                    });
                } else {
                    var newImageID = ImageURL;
                    values = [UnitNo, Level, Block, UnitName, UnitID, newImageID, UnitID, ImageID];
                    connection.query('update unit set UnitNo=?,Level=?,Block=?,UnitName=? where UnitID=?;Update unitimage set ImageID = ? where UnitID = ? and ImageID = ?;', values, function (error, results, fields) {
                        // And done with the connection.
                        //connection.release();
                        // Handle error after the release.
                        if (error) {
                            callback(error);
                            return;
                        }
                        //else callback(null, results);
                    });
                }


                for (var i in BeaconID) {
                    var records = [BeaconID[i], UnitID, BeaconID[i], UnitID];
                    console.log(BeaconID[i]);
                    if (i == BeaconID.length - 1) {
                        connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?);', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    } else {
                        connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?);', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    }
                }

                for (var i = 0; i < BeaconID.length; i++) {
                    if (i == 0) {
                        existingRecords += "SELECT " + BeaconID[i] + ", " + UnitID;
                    } else {
                        existingRecords += " UNION ALL SELECT " + BeaconID[i] + ", " + UnitID;
                    }
                }

                if (BeaconID.length == 0) {
                    connection.query('DELETE FROM beaconunit WHERE UnitID=?;', UnitID, function (error, results, fields) {
                        console.log(existingRecords);
                        connection.release();
                        // Handle error after the release.
                        if (error) callback(error);
                        else callback(null, results)
                    });
                } else {
                    connection.query('DELETE FROM beaconunit WHERE UnitID=? AND (BeaconID, UnitID) NOT IN (' + existingRecords + ');', UnitID, function (error, results, fields) {
                        console.log(existingRecords);
                        connection.release();
                        // Handle error after the release.
                        if (error) callback(error);
                        else callback(null, results)
                    });
                }
            });
        } else if (event.action == "deleteUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UnitID = event.UnitID;
                var values = [UnitID, UnitID, UnitID];
                connection.query('delete from unitimage where UnitID=?; delete from beaconunit where UnitID=?;delete from unit where UnitID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UnitNo = event.UnitNo;
                var Level = event.Level;
                var Block = event.Block;
                var ImageURL = event.ImageURL;
                var Category = event.Category;
                var UnitName = event.UnitName;
                var BeaconID = event.BeaconID;
                var records = [UnitNo, Level, Block, UnitName, ImageURL, Category];

                if (isNaN(ImageURL)) {
                    connection.query('insert into unit values(0 , ?, ?, ?, ?);insert into image values(0 , ?, ?)', records, function (error, results, fields) {
                        // Handle error after the release.
                        if (error) {
                            callback(error);
                            return;
                        }
                        console.log(results[0].insertId + "" + results[1].insertId);
                        var UnitID = results[0].insertId;
                        var ImageID = results[1].insertId;
                        records = [UnitID, ImageID];
                        connection.query('insert into unitimage values(0 , ?, ?)', records, function (error, results, fields) {
                            //connection.release();
                            // Handle error after the release.
                            if (error) callback(error);
                            if (BeaconID.length == 0) {
                                connection.release();
                                callback(null, results);
                            }
                        });

                        for (var i in BeaconID) {
                            records = [BeaconID[i], UnitID, BeaconID[i], UnitID];
                            console.log(BeaconID[i]);
                            if (i == BeaconID.length - 1) {
                                connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?)', records, function (error, results, fields) {
                                    connection.release();
                                    // Handle error after the release.
                                    if (error) callback(error);
                                    else callback(null, results)
                                });
                            } else {
                                connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?)', records, function (error, results, fields) {
                                    // Handle error after the release.
                                    if (error) {
                                        callback(error);
                                        return;
                                    }
                                });
                            }
                        }
                    });
                } else {
                    records = [UnitNo, Level, Block, UnitName];
                    connection.query('insert into unit values(0 , ?, ?, ?, ?)', records, function (error, results, fields) {
                        // Handle error after the release.
                        if (error) {
                            callback(error);
                            return;
                        }
                        var UnitID = results.insertId;
                        var ImageID = ImageURL;
                        records = [UnitID, ImageID];
                        connection.query('insert into unitimage values(0 , ?, ?)', records, function (error, results, fields) {
                            //connection.release();
                            // Handle error after the release.
                            if (error) callback(error);
                            if (BeaconID.length == 0) {
                                connection.release();
                                callback(null, results);
                            }
                        });

                        for (var i in BeaconID) {
                            records = [BeaconID[i], UnitID, BeaconID[i], UnitID];
                            console.log(BeaconID[i]);
                            if (i == BeaconID.length - 1) {
                                connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?)', records, function (error, results, fields) {
                                    connection.release();
                                    // Handle error after the release.
                                    if (error) callback(error);
                                    else callback(null, results)
                                });
                            } else {
                                connection.query('INSERT INTO beaconunit (BeaconID, UnitID) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BUID FROM beaconunit WHERE BeaconID=? AND UnitID=?)', records, function (error, results, fields) {
                                    // Handle error after the release.
                                    if (error) {
                                        callback(error);
                                        return;
                                    }
                                });
                            }
                        }
                    });
                }



            });
        } else if (event.action == "getUnitById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UnitID = event.UnitID;
                connection.query('SELECT u.UnitID,UnitNo,Level,Block,UnitName,ImageURL,i.ImageID FROM unit as u join unitimage as ui on u.UnitID = ui.UnitID join image as i on ui.ImageID = i.ImageID where u.UnitID = ?;', UnitID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "BeaconDirection") {
        if (event.action == "getBeaconDirection") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from bdirection', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putBeaconDirection") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var CurrentBID = event.CurrentBID;
                var PreviousBID = event.PreviousBID;
                var NextBID = event.NextBID;
                var DirectID = event.DirectID;
                var Compass = event.Compass;
                var BDirectionID = event.BDirectionID;
                var Note = event.Note;
                var values = [CurrentBID, PreviousBID, NextBID, DirectID, Compass, Note, BDirectionID];
                connection.query('update bdirection set CurrentBID=?,PreviousBID=?,NextBID=?,DirectID=?,Compass=?, Note=? where BDirectionID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "deleteBeaconDirection") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BDirectionID = event.BDirectionID;
                connection.query('delete from bdirection where BDirectionID=?', BDirectionID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createBeaconDirection") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var CurrentBID = event.CurrentBID;
                var PreviousBID = event.PreviousBID;
                var NextBID = event.NextBID;
                var DirectID = event.DirectID;
                var Compass = event.Compass;
                var Note = event.Note;
                var records = [CurrentBID, PreviousBID, NextBID, DirectID, Compass, Note];
                connection.query('insert into bdirection values(0 , ?, ?, ?, ?, ?, ?)', records, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "getBeaconDirectionById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BDirectionID = event.BDirectionID;
                connection.query('SELECT * from bdirection where BDirectionID = ?', BDirectionID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "BeaconRelation") {
        if (event.action == "getBeaconRelation") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from brelation', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putBeaconRelation") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                var NewBeaconID = event.NewBeaconID;
                var RelatedBeacon = event.RelatedBeacon;
                var existingRecords = "";
                /*
                var BRID = event.BRID;
                var values = [BeaconID, RelatedBeacon, BRID];
                connection.query('update brelation set BeaconID=?,RelatedBeacon=? where BRID=?', values, function (error, results, fields) {
                  // And done with the connection.
                  connection.release();
                  // Handle error after the release.
                  if (error) callback(error);
                  else callback(null, results);
                });*/

                for (var i in RelatedBeacon) {
                    var records = [BeaconID, RelatedBeacon[i], BeaconID, RelatedBeacon[i]];
                    console.log(RelatedBeacon[i]);
                    if (i == RelatedBeacon.length - 1) {
                        connection.query('INSERT INTO brelation (BeaconID, RelatedBeacon) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BRID FROM brelation WHERE BeaconID=? AND RelatedBeacon=?)', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    } else {
                        connection.query('INSERT INTO brelation (BeaconID, RelatedBeacon) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BRID FROM brelation WHERE BeaconID=? AND RelatedBeacon=?)', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    }
                }

                for (var i = 0; i < RelatedBeacon.length; i++) {
                    console.log('Loop number ' + [i]);
                    console.log('Except Beacon ' + RelatedBeacon[i]);
                    if (i == 0) {
                        existingRecords += "SELECT " + BeaconID + ", " + RelatedBeacon[i];
                    } else {
                        existingRecords += " UNION ALL SELECT " + BeaconID + ", " + RelatedBeacon[i];
                    }
                }

                connection.query('DELETE FROM brelation WHERE BeaconID=? AND (BeaconID, RelatedBeacon) NOT IN (' + existingRecords + ')', BeaconID, function (error, results, fields) {

                    // Handle error after the release.
                    if (error) {
                        callback(error);
                        return;
                    }
                });
                var values = [NewBeaconID, BeaconID];
                connection.query('update brelation set BeaconID=? where BeaconID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "deleteBeaconRelation") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                connection.query('delete from brelation where BeaconID=?', BeaconID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createBeaconRelation") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                var RelatedBeacon = event.RelatedBeacon;
                /*
                var records = [BeaconID,RelatedBeacon];
                connection.query('insert into brelation values(0 , ?, ?)', records , function (error, results, fields) {
                  // And done with the connection.
                  connection.release();
                  // Handle error after the release.
                  if (error) callback(error);
                  else callback(null,results);
                });*/

                for (var i in RelatedBeacon) {
                    var records = [BeaconID, RelatedBeacon[i], BeaconID, RelatedBeacon[i]];
                    console.log(RelatedBeacon[i]);
                    if (i == RelatedBeacon.length - 1) {
                        connection.query('INSERT INTO brelation (BeaconID, RelatedBeacon) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BRID FROM brelation WHERE BeaconID=? AND RelatedBeacon=?)', records, function (error, results, fields) {
                            connection.release();
                            // Handle error after the release.
                            if (error) callback(error);
                            else callback(null, results);
                        });
                    } else {
                        connection.query('INSERT INTO brelation (BeaconID, RelatedBeacon) SELECT ?, ? FROM dual WHERE NOT EXISTS (SELECT BRID FROM brelation WHERE BeaconID=? AND RelatedBeacon=?)', records, function (error, results, fields) {
                            // Handle error after the release.
                            if (error) {
                                callback(error);
                                return;
                            }
                        });
                    }
                }

            });
        } else if (event.action == "getBeaconRelationById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                connection.query('SELECT * from brelation where BeaconID = ?', BeaconID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "BeaconUnit") {
        if (event.action == "getBeaconUnit") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from beaconunit', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putBeaconUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                var UnitID = event.UnitID;
                var BUID = event.BUID;
                var values = [BeaconID, UnitID, BUID];
                connection.query('update beaconunit set BeaconID=?,UnitID=? where BUID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "deleteBeaconUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BUID = event.BUID;
                connection.query('delete from beaconunit where BUID=?', BUID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createBeaconUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var BeaconID = event.BeaconID;
                var UnitID = event.UnitID;
                var records = [BeaconID, UnitID];
                connection.query('insert into beaconunit values(0 , ?, ?)', records, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "getBeaconUnitById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var UnitID = event.UnitID;
                connection.query('SELECT b.BeaconID FROM beacon as b join beaconunit as bu on b.BeaconID = bu.BeaconID where UnitID = ?;', UnitID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "FacilityUnit") {
        if (event.action == "getFacilityUnit") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from facilityunit', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "putFacilityUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityID = event.FacilityID;
                var UnitID = event.UnitID;
                var FUID = event.FUID;
                var values = [FacilityID, UnitID, FUID];
                connection.query('update facilityunit set FacilityID=?,UnitID=? where FUID=?', values, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "deleteFacilityUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FUID = event.FUID;
                connection.query('delete from facilityunit where FUID=?', FUID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "createFacilityUnit") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityID = event.FacilityID;
                var UnitID = event.UnitID;
                var records = [FacilityID, UnitID];
                connection.query('insert into facilityunit values(0 , ?, ?)', records, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        } else if (event.action == "getFacilityUnitById") {
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                var FacilityID = event.FacilityID;
                connection.query('SELECT u.UnitID FROM unit as u join facilityunit as fu on u.UnitID = fu.UnitID where FacilityID = ?;', FacilityID, function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    } else if (event.type == "Image") {
        if (event.action == "getImage") {
            //prevent timeout from waiting event loop
            context.callbackWaitsForEmptyEventLoop = false;
            pool.getConnection(function (err, connection) {
                if (err) {
                    callback(err);
                    return;
                }
                // Use the connection
                connection.query('SELECT * from image where Category="Unit"', function (error, results, fields) {
                    // And done with the connection.
                    connection.release();
                    // Handle error after the release.
                    if (error) callback(error);
                    else callback(null, results);
                });
            });
        }
    }
};